:-consult("TDA_Base_21394548_MoyaMonsalve.pl").
:-consult("TDA_Option_21394548_MoyaMonsalve.pl").
:-consult("TDA_Flow_21394548_MoyaMonsalve.pl").
:-consult("TDA_Chatbot_21394548_MoyaMonsalve.pl").
:-consult("TDA_User_21394548_MoyaMonsalve.pl").
:-consult("TDA_ChatHistory_21394548_MoyaMonsalve.pl").
:-consult("TDA_System_21394548_MoyaMonsalve.pl").

%Funcion 1: option

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option),write(Option).

%Consulta 2:
%option(1,"Opcion1",1,1,[],Option),write(Option).

%Consulta 3:
%option(1,"Opcion1","String",1,[],Option),write(Option).

%Funcion 2: flow

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow).

%Consulta 2
%flow(1,"Flujo1",[],Flow),write(Flow).

%Consulta 3:
%flow("Flujo1","String",[],Flow),write(Flow).

%Funcion 3: flowaddoption

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1],Flow),write(Flow),nl,flowaddoption(Flow,Option2,New_Flow),write(New_Flow).

%Consulta 2:
%option(1,"Opcion1",1,1,["Viajar"],Option),write(Option),nl,flow(1,"Flujo1",[],Flow),write(Flow),nl,flowaddoption(Flow,Option,New_Flow),write(New_Flow).

%Consulta 3:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(1,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1],Flow),write(Flow),nl,flowaddoption(Flow,Option2,New_Flow),write(New_Flow).

%Funcion 4: chatbot

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot).

%Consulta 2:
%chatbot(1,"Chatbot1","Bienvenido",1,[],Chatbot),write(Chatbot).

%Consulta 3:
%chatbot(1,"Chatbot1","Bienvenido","String",[],Chatbot),write(Chatbot).

%Funcion 5: chatbotaddflow

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow1),flow(2,"Flujo2",[],Flow2),write(Flow1),nl,write(Flow2),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow1],Chatbot),write(Chatbot),nl,chatbotaddflow(Chatbot,Flow2,New_Chatbot),write(New_Chatbot).

%Consulta 2:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[],Chatbot),write(Chatbot),nl,chatbotaddflow(Chatbot,Flow,New_Chatbot),write(New_Chatbot).

%Consulta 3:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow1),flow(1,"Flujo2",[],Flow2),write(Flow1),nl,write(Flow2),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow1],Chatbot),write(Chatbot),nl,chatbotaddflow(Chatbot,Flow2,New_Chatbot),write(New_Chatbot).

%Funcion 6: system

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),write(User1),nl,system("Sistema1",1,[Chatbot],[User1],[],System),write(System).

%Consulta 2:
%user("User_Name1","User_Email1","User_Password1",[],User1),write(User1),nl,system("Sistema1",1,[],[User1],[],System),write(System).

%Consulta 3:
%user("User_Name1","User_Email1","User_Password1",[],User1),write(User1),nl,system("Sistema1","String",[],[User1],[],System),write(System).

%Funcion 7: systemaddchatbot

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow1),flow(2,"Flujo2",[],Flow2),write(Flow1),nl,write(Flow2),nl,chatbot(1,"Chatbot1","Bienvenido1",1,[Flow1],Chatbot1),chatbot(2,"Chatbot2","Bienvenido2",2,[Flow2],Chatbot2),write(Chatbot1),nl,write(Chatbot2),nl, user("User_Name1","User_Email1","User_Password1",[],User1),write(User1),nl,system("Sistema1",1,[Chatbot1],[User1],[],System),write(System),nl,systemaddchatbot(System,Chatbot2,New_System),write(New_System).

%Consulta 2:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow1),flow(2,"Flujo2",[],Flow2),write(Flow1),nl,write(Flow2),nl,chatbot(1,"Chatbot1","Bienvenido1",1,[Flow1],Chatbot),write(Chatbot),nl, user("User_Name1","User_Email1","User_Password1",[],User1),write(User1),nl,system("Sistema1",1,[],[User1],[],System),write(System),nl,systemaddchatbot(System,Chatbot,New_System),write(New_System).

%Consulta 3:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow1),flow(2,"Flujo2",[],Flow2),write(Flow1),nl,write(Flow2),nl,chatbot(1,"Chatbot1","Bienvenido1",1,[Flow1],Chatbot1),chatbot(1,"Chatbot2","Bienvenido2",2,[Flow2],Chatbot2),write(Chatbot1),nl,write(Chatbot2),nl, user("User_Name1","User_Email1","User_Password1",[],User1),write(User1),nl,system("Sistema1",1,[Chatbot1],[User1],[],System),write(System),nl,systemaddchatbot(System,Chatbot2,New_System),write(New_System).

%Funcion 8: systemadduser

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1],[],System),write(System),nl,systemadduser(System,User2,New_System),write(New_System),nl.

%Consulta 2:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),write(User1),nl,system("Sistema1",1,[Chatbot],[],[],System),write(System),nl,systemadduser(System,User1,New_System),write(New_System),nl.

%Consulta 3:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name1","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1],[],System),write(System),nl,systemadduser(System,User2,New_System),write(New_System),nl.

%Funcion 9: systemlogin

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name1","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1,User2],[],System),write(System),nl,systemlogin(System,User2,New_System),write(New_System),nl.

%Consulta 2:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1],[],System),write(System),nl,systemlogin(System,User2,New_System),write(New_System),nl.

%Consulta 3:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name1","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1],[],System),write(System),nl,systemlogin(System,User2,New_System),write(New_System),nl.

%Funcion 10: systemlogout

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1,User2],[],System),write(System),nl,systemlogin(System,User2,New_System1),write(New_System1),nl,systemlogout(New_System1,New_System2),write(New_System2).

%Consulta 2:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1,User2],[],System),write(System),nl,systemlogout(System,New_System),write(New_System).

%Consulta 3:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[],[],System),write(System),nl,systemlogout(System,New_System),write(New_System).

%Funcion 11: systemtalkrec

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1,User2],[],System),write(System),nl,systemlogin(System,User2,New_System),write(New_System),nl,systemtalkrec(New_System,1,Systemout),write(Systemout).

%Consulta 2:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1,User2],[],System),write(System),nl,systemtalkrec(System,1,Systemout),write(Systemout).

%Consulta 3:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1,User2],[],System),write(System),nl,systemlogin(System,User2,New_System),write(New_System),nl,systemtalkrec(New_System,[],Systemout),write(Systemout).

%Funcion 12: systemsynthesis

%Consulta 1:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",["12/11/2023",["User_Name2:",1],["Chatbot1:","Bienvenido"],["->","Flujo1"],["1)","Opcion1"],["2)","Opcion2"]],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1,User2],[],System),write(System),nl,systemlogin(System,User2,New_System),write(New_System),nl,systemsynthesis(New_System,"User_Name2").

%Consulta 2:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1,User2],[],System),write(System),nl,systemlogin(System,User2,New_System),write(New_System),nl,systemsynthesis(New_System,"User_Name2").

%Consulta 3:
%option(1,"Opcion1",1,1,["Viajar"],Option1),option(2,"Opcion2",2,2,[],Option2),write(Option1),nl,write(Option2),nl,flow(1,"Flujo1",[Option1,Option2],Flow),write(Flow),nl,chatbot(1,"Chatbot1","Bienvenido",1,[Flow],Chatbot),write(Chatbot),nl,user("User_Name1","User_Email1","User_Password1",[],User1),user("User_Name2","User_Email2","User_Password2",[],User2),write(User1),nl,write(User2),nl,system("Sistema1",1,[Chatbot],[User1,User2],[],System),write(System),nl,systemlogin(System,User2,New_System),write(New_System),nl,systemsynthesis(New_System,"User_Name3").