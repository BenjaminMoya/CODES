:-consult("TDA_Base_21394548_MoyaMonsalve.pl").
:-consult("TDA_Option_21394548_MoyaMonsalve.pl").

%TDA Flow | Version 1.1

%-----------------------------------------------------------------------

%Dominio:
%Flow_Id:Integer
%Flow_Name_Msg:String
%Flow_Options:List
%Flow:List
%car:Funcion
%New_Flow:List
%New_Options:List
%Option_Code:Integer
%Option_Msg:String
%Option_ChatbotCodelink:Integer
%Option_InitialFlowCodeLink:Integer
%Option_Keywords:Lists
%Option:List

%-----------------------------------------------------------------------

%Constructores

%Descripcion:Crea un flujo
%Predicado:flow(Flow_Id,Flow_Name_Msg,Flow_Options,Flow)
%Clausulas:
flow(Flow_Id,Flow_Name_Msg,Flow_Options,[Flow_Id,Flow_Name_Msg,Flow_Options]):-
    integer(Flow_Id),
    string(Flow_Name_Msg),
    \+ integer(Flow_Options),
    \+ string(Flow_Options).

%Pertenencia

%Descripcion:Verifica si un elemento es un flujo
%Predicado:is_flow(Flow)
%Clausulas:
is_flow(Flow):-
    get_flow_id(Flow,Flow_Id),
    get_flow_namemsg(Flow,Flow_Name_Msg),
    get_flow_options(Flow,Flow_Options),
    flow(Flow_Id,Flow_Name_Msg,Flow_Options,Flow).

%Selectores

%Descripcion:Recupera el id del flujo
%Predicado:get_flow_id(Flow,Flow_Id) 
%Clausulas:
get_flow_id(Flow,Flow_Id):-
    car(Flow,Flow_Id).

%Descripcion:Recupera el mensaje del flujo
%Predicado:get_flow_namemsg(Flow,Flow_Name_Msg) 
%Clausulas:
get_flow_namemsg(Flow,Flow_Name_Msg):-
    cadr(Flow,Flow_Name_Msg).

%Descripcion:Recupera las opciones del flujo
%Predicado:get_flow_options(Flow,Flow_Options) 
%Clausulas:
get_flow_options(Flow,Flow_Options):-
    caddr(Flow,Flow_Options).

%Descripcion:Recupera los id de las opciones
%Predicado:get_flow_options_id(Flow,Flow_Options_Id) 
%Clausulas:
get_flow_options_id(Flow,Flow_Options_Id):-
    get_flow_options(Flow,Flow_Options),
    maplist(car,Flow_Options,Flow_Options_Id).

%Descripcion:Recupera la opcion segun la palabra clave
%Predicado:get_option_bykeyword(Flow,Keyword,Option)
%Clausulas:
get_option_bykeyword(Flow,_,_):-
    get_flow_options(Flow,Flow_Options),
    Flow_Options=[],
    write("No hay una opcion relacionada con la palabra clave"),
    nl.
get_option_bykeyword(Flow,Keyword,Option):-
    get_flow_options(Flow,Flow_Options),
    car(Flow_Options,Option1),
    get_option_keywords(Option1,Option_Keywords),
    in(Option_Keywords,Keyword),
    get_option_code(Option1,Option_Code),
    get_option_msg(Option1,Option_Msg),
    get_option_chatbotcodelink(Option1,Option_ChatbotCodelink),
    get_option_initialflowcodelink(Option1,Option_InitialFlowCodeLink),
    option(Option_Code,Option_Msg,Option_ChatbotCodelink,Option_InitialFlowCodeLink,Option_Keywords,Option).
get_option_bykeyword(Flow,Keyword,_):-
    get_flow_options(Flow,Flow_Options),
    car(Flow_Options,Option),
    get_option_keywords(Option,Option_Keywords),
    \+ in(Option_Keywords,Keyword),
    delete_first_element(Flow_Options,New_Flow_Options),
    get_flow_id(Flow,Flow_Id),
    get_flow_namemsg(Flow,Flow_Name_Msg),
    flow(Flow_Id,Flow_Name_Msg,New_Flow_Options,New_Flow),
    get_option_bykeyword(New_Flow,Keyword,_).

%Descripcion:Recupera la opcion segun la seleccion de un numero
%Predicado:get_option_byid(Flow,Id,Option)
%Clausulas:
get_option_byid(Flow,_,_):-
    get_flow_options(Flow,Flow_Options),
    Flow_Options=[],
    write("No hay una opcion relacionada con la seleccion"),
    nl.
get_option_byid(Flow,Id,Option):-
    get_flow_options(Flow,Flow_Options),
    car(Flow_Options,Option1),
    get_option_code(Option,Option_Code),
    Id=Option_Code,
    get_option_msg(Option1,Option_Msg),
    get_option_chatbotcodelink(Option1,Option_ChatbotCodelink),
    get_option_initialflowcodelink(Option1,Option_InitialFlowCodeLink),
    get_option_keywords(Option,Option_Keywords),
    option(Option_Code,Option_Msg,Option_ChatbotCodelink,Option_InitialFlowCodeLink,Option_Keywords,Option).
get_option_byid(Flow,Id,_):-
    get_flow_options(Flow,Flow_Options),
    car(Flow_Options,Option),
    get_option_code(Option,Option_Code),
    \+ Id=Option_Code,
    delete_first_element(Flow_Options,New_Flow_Options),
    get_flow_id(Flow,Flow_Id),
    get_flow_namemsg(Flow,Flow_Name_Msg),
    flow(Flow_Id,Flow_Name_Msg,New_Flow_Options,New_Flow),
    get_option_byid(New_Flow,Id,_).    

%Modificadores

%Descripcion:Añade una opcion al flujo sin repetir su id
%Predicado:flowaddoption(Flow,Option,New_Flow)
%Clausulas:
flowaddoption(_,Option,_):-
    \+ is_option(Option),
    write("Opcion invalida"),
    nl.
flowaddoption(Flow,_,_):-
    \+ is_flow(Flow),
    write("Flujo invalido"),
    nl.
flowaddoption(Flow,Option,New_Flow):-
    is_option(Option),
    is_flow(Flow),
    get_flow_options_id(Flow,Flow_Options_Id),
    get_option_code(Option,Option_Code),
    in(Flow_Options_Id,Option_Code),
    get_flow_id(Flow,Flow_Id),
    get_flow_namemsg(Flow,Flow_Name_Msg),
    get_flow_options(Flow,Flow_Options),
    flow(Flow_Id,Flow_Name_Msg,Flow_Options,New_Flow).
flowaddoption(Flow,Option,New_Flow):-
    is_option(Option),
    is_flow(Flow),
    get_flow_options_id(Flow,Flow_Options_Id),
    get_option_code(Option,Option_Code),
    \+ in(Flow_Options_Id,Option_Code),
    get_flow_id(Flow,Flow_Id),
    get_flow_namemsg(Flow,Flow_Name_Msg),
    get_flow_options(Flow,Flow_Options),
    put_last(Flow_Options,Flow_Options,New_Options),
    flow(Flow_Id,Flow_Name_Msg,New_Options,New_Flow).