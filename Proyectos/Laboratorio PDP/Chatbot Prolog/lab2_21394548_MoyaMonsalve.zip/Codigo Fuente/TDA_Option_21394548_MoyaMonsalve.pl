:-consult("TDA_Base_21394548_MoyaMonsalve.pl").

%TDA Option | Version 1.2

%-----------------------------------------------------------------------

%Dominio:
%Option_Code:Integer
%Option_Msg:String
%Option_ChatbotCodelink:Integer
%Option_InitialFlowCodeLink:Integer
%Option_Keywords:Lists
%Option:List
%New_Msg:String
%New_Option:List
%New_Keywords:List

%-----------------------------------------------------------------------

%Constructores

%Descripcion:Crea una opcion 
%Predicado:option(Option_Code,Option_Msg,Option_ChatbotCodelink,Option_InitialFlowCodeLink,Option_Keywords,Option)
%Clausulas:
option(Option_Code,Option_Msg,Option_ChatbotCodelink,Option_InitialFlowCodeLink,Option_Keywords,[Option_Code,Option_Msg,Option_ChatbotCodelink,Option_InitialFlowCodeLink,Option_Keywords]):-
    integer(Option_Code),
    string(Option_Msg),
    integer(Option_ChatbotCodelink),
    integer(Option_InitialFlowCodeLink),
    \+ integer(Option_Keywords),
    \+ string(Option_Keywords).

%Pertenencia

%Descripcion:Verifica si un elemento es una opcion
%Predicado:is_option(Option) 
%Clausulas:
is_option(Option):-
    get_option_code(Option,Option_Code),
    get_option_msg(Option,Option_Msg),
    get_option_chatbotcodelink(Option,Option_ChatbotCodelink),
    get_option_initialflowcodelink(Option,Option_InitialFlowCodeLink),
    get_option_keywords(Option,Option_Keywords),
    option(Option_Code,Option_Msg,Option_ChatbotCodelink,Option_InitialFlowCodeLink,Option_Keywords,Option).

%Selectores

%Descripcion:Recupera el codigo de la opcion
%Predicado:get_option_code(Option,Option_Code)
%Clausulas:
get_option_code(Option,Option_Code):-
    car(Option,Option_Code).

%Descripcion:Recupera el mensaje de la opcion
%Predicado:get_option_msg(Option,Option_Msg)
%Clausulas:
get_option_msg(Option,Option_Msg):-
    cadr(Option,Option_Msg).

%Descripcion:Recupera el codigo de enlace al chatbot 
%Predicado:get_option_chatbotcodelink(Option,Option_ChatbotCodelink)
%Clausulas:
get_option_chatbotcodelink(Option,Option_ChatbotCodelink):-
    caddr(Option,Option_ChatbotCodelink).

%Descripcion:Recupera el codigo de enlace al flujo inicial
%Predicado:get_option_initialflowcodelink(Option,Option_InitialFlowCodeLink)
%Clausulas:
get_option_initialflowcodelink(Option,Option_InitialFlowCodeLink):-
    cadddr(Option,Option_InitialFlowCodeLink).

%Descripcion:Recupera las palabras claves
%Predicado:get_option_keywords(Option,Option_Keywords)
%Clausulas:
get_option_keywords(Option,Option_Keywords):-
    caddddr(Option,Option_Keywords).

%Modificadores

%Descripcion:Modifica el mensaje de la opcion
%Predicado:set_option_msg(Option,New_Msg,New_Option)
%Clausulas:
set_option_msg(Option,_,_):-
    \+ is_option(Option),
    write("Opcion invalida"),
    nl.
set_option_msg(_,New_Msg,_):-
    \+ string(New_Msg),
    write("Mensaje de opcion invalido"),
    nl.
set_option_msg(Option,New_Msg,New_Option):-
    is_option(Option),
    string(New_Msg),
    get_option_code(Option,Option_Code),
    get_option_chatbotcodelink(Option,Option_ChatbotCodelink),
    get_option_initialflowcodelink(Option,Option_InitialFlowCodeLink),
    get_option_keywords(Option,Option_Keywords),
    option(Option_Code,New_Msg,Option_ChatbotCodelink,Option_InitialFlowCodeLink,Option_Keywords,New_Option).

%Descripcion:Borra una palabra clave
%Predicado:option_delete_keyword(Option,Keyword,New_Option)
%Clausulas:
option_delete_keyword(Option,_,_):-
    get_option_keywords(Option,Option_Keywords),
    Option_Keywords=[],
    write("No hay mas opciones"),
    nl.
option_delete_keyword(Option,Keyword,New_Option):-
    get_option_keywords(Option,Option_Keywords),
    delete_element(Option_Keywords,Keyword,New_Keywords),
    get_option_code(Option,Option_Code),
    get_option_msg(Option,Option_Msg),
    get_option_chatbotcodelink(Option,Option_ChatbotCodelink),
    get_option_initialflowcodelink(Option,Option_InitialFlowCodeLink),
    option(Option_Code,Option_Msg,Option_ChatbotCodelink,Option_InitialFlowCodeLink,New_Keywords,New_Option).