%TDA BASE | Version 1.2

%-----------------------------------------------------------------------

%Dominio:
%E:Any Type
%E1:Any Type
%E2:Any Type
%H:Any Type
%T:Any Type
%NewT:Any Type
%R:Integer
%NewR:Integer
%I:Integer
%NewI:Integer
%Xn:Integer
%Xn1:Integer
%L1:List
%L2:List

%-----------------------------------------------------------------------

%Descripcion:Predicado que coloca un elemento en la cabeza de una lista
%Predicado:put_first(E,[H|T],[E,H|T]) 
%Clausulas: 
put_first(E,[],[E]).
put_first(E,[H|T],[E,H|T]).

%Descripcion:Predicado que coloca un elemento ultimo en una lista
%Predicado:put_last([H|T],E,[H|NewT])
%Clausulas:
put_last([],E,[E]).
put_last([H|T],E,[H|NewT]):-
    put_last(T,E,NewT).

%Descripcion:Predicado que enmtrega el largo de una lista
%Predicado:mylength([_|T],R)
%Clausulas:
mylength([],0).
mylength([_|T],R):-
    length(T,NewR),R is NewR+1.

%Descripcion:Predicado que coloca un elemento en una lista segun indice
%Predicado:put_index([H|T],E,I,[H|NewT])
%Clausulas:
put_index([],E,0,[E]).
put_index([H|T],E,0,[E,H|T]).
put_index([H|T],E,I,[H|NewT]):-
    NewI is I-1,
    put_index(T,E,NewI,NewT).

%Descripcion:Predicado que elimina un elemento de la lista
%Predicado:delete_element([H|T],E,[H|NewT])
%Clausulas:
delete_element([H|T],E,T):-H=E.
delete_element([H|T],E,[H|NewT]):-
    delete_element(T,E,NewT).

%Descripcion:Predicado que elimina el primer elemento de la lista
%Predicado:delete_first_element([H|T],T)
%Clausulas:
delete_first_element([_|T],T).

%Descripcion:Predicado que une listas.
%Predicado:listunion(L1,L2,[L1|L2]) 
%Clausulas:
listunion(L1,L2,[L1|L2]).

%Descripcion:Predicado que recupera el primer elemento de una lista
%Predicado:car([H|_],H) 
%Clausulas:
car([H|_],H).

%Descripcion:Predicado que recupera la cola de la lista
%Predicado:cdr([_|T],T) 
%Clausulas:
cdr([_|T],T).

%Descripcion:Predicado que recupera un elemento segun indice
%Predicado:index_search([_|T],I,E)
%Clausulas:
index_search([],0,[]).
index_search([H|_],0,E):-H=E.
index_search([_|T],I,E):-
    NewI is I-1,
    index_search(T,NewI,E).
    
%Descripcion:Predicado que verifica si un elemento esta en una lista
%Predicado:in([_|T],E) 
%Clausulas:
in([H|_],E):-H=E.
in([_|T],E):-
    in(T,E).

%Descripcion:Predicado que cambia un elemento de la lista por otro
%Predicado:change_element([H|T],E1,E2,[H|NewT]) 
%Clausulas:
change_element([H|T],E1,E2,[E1|T]):-E2=H.
change_element([H|T],E1,E2,[H|NewT]):-
    change_element(T,E1,E2,NewT).

%Descripcion:Predicado que recupera el segundo elemento de una lista
%Predicado:cadr([_,H|_],H)
%Clausulas:
cadr([_,H|_],H).

%Descripcion:Predicado que recupera el tercer elemento de una lista
%Predicado:caddr([_,_,H|_],H)
%Clausulas:    
caddr([_,_,H|_],H).

%Descripcion:Predicado que recupera el cuarto elemento de una lista
%Predicado:cadddr([_,_,_,H|_],H)
%Clausulas:
cadddr([_,_,_,H|_],H).

%Descripcion:Predicado que recupera el quinto elemento de una lista
%Predicado:caddddr([_,_,_,_,H|_],H)
%Clausulas:
caddddr([_,_,_,_,H|_],H).

%Descripcion:Predicado que recupera el sexto elemento de una lista
%Predicado:cadddddr([_,_,_,_,_,H|_],H)
%Clausulas:
cadddddr([_,_,_,_,_,H|_],H).