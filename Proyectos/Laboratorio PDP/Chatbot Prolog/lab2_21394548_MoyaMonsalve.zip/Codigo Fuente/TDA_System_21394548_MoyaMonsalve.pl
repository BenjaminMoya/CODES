:-consult("TDA_Base_21394548_MoyaMonsalve.pl").
:-consult("TDA_Option_21394548_MoyaMonsalve.pl").
:-consult("TDA_Flow_21394548_MoyaMonsalve.pl").
:-consult("TDA_Chatbot_21394548_MoyaMonsalve.pl").
:-consult("TDA_User_21394548_MoyaMonsalve.pl").
:-consult("TDA_ChatHistory_21394548_MoyaMonsalve.pl").

%TDA System | Version 1.4

%-----------------------------------------------------------------------

%Dominio:
%System_Name:String
%System_InitialChatbotCodeLink:Integer
%System_Users:List
%System_User_In_Session:List
%System:List
%System_Chatbots_Id:Integer
%System_Users_Names:List
%Initial_Chatbot:List
%Chatbot_Name:String
%Chatbot_WelcomeMsg:String
%Chatbot_StartFlowId:Integer
%Flow_Id:Integer
%Chatbot:List
%Chatbot_Id:Integer
%Option_Keywords:Lists
%System_New_Chatbots:List
%New_System:List
%New_Users:List
%New_User_In_Session:List
%User:List
%User1:List
%User2:List
%User_Name:String
%User_Name1:String
%User_Name2:String
%Out:String
%User_Email:String
%User_Password:String
%User_ChatHistory:List

%-----------------------------------------------------------------------

%Constructores

%Descripcion:Crea un sistema
%Predicado:system(System_Name,System_InitialChatbotCodeLink,System_Chatbots,System_Users,System_User_In_Session,System) 
%Clausulas:
system(System_Name,System_InitialChatbotCodeLink,System_Chatbots,System_Users,System_User_In_Session,[System_Name,System_InitialChatbotCodeLink,System_Chatbots,System_Users,System_User_In_Session]):-
	string(System_Name),
	integer(System_InitialChatbotCodeLink),
	\+ string(System_Chatbots),
	\+ integer(System_Chatbots),
	\+ string(System_Users),
	\+ integer(System_Users),	 
	\+ string(System_User_In_Session),
	\+ integer(System_User_In_Session).

%Pertenencia

%Descripcion:Verifica si el elemento es un sistema
%Predicado:is_system(System) 
%Clausulas:
is_system(System):-
	get_system_name(System,System_Name),
	get_system_initialchatbotcodelink(System,System_InitialChatbotCodeLink),
	get_system_chatbots(System,System_Chatbots),
	get_system_users(System,System_Users),
	get_system_user_in_sesion(System,System_User_In_Session),
	system(System_Name,System_InitialChatbotCodeLink,System_Chatbots,System_Users,System_User_In_Session,System).

%Selectores

%Descripcion:Recupera el nombre del sistema
%Predicado:get_system_name(System,System_Name) 
%Clausulas:
get_system_name(System,System_Name):-
	car(System,System_Name).

%Descripcion:Recupera el id del chatbot inicial
%Predicado:get_system_initialchatbotcodelink(System,System_InitialChatbotCodeLink) 
%Clausulas:
get_system_initialchatbotcodelink(System,System_InitialChatbotCodeLink):-
	cadr(System,System_InitialChatbotCodeLink).

%Descripcion:Recupera los chatbots del sistema
%Predicado:get_system_chatbots(System,System_Chatbots)
%Clausulas:
get_system_chatbots(System,System_Chatbots):-
	caddr(System,System_Chatbots).

%Descripcion:Recupera los usuarios del sistema
%Predicado:get_system_users(System,System_Users) 
%Clausulas:
get_system_users(System,System_Users):-
	cadddr(System,System_Users).

%Descripcion:Recupera el usuario que inicio sesion en el sistema
%Predicado:get_system_user_in_sesion(System,System_Users) 
%Clausulas:
get_system_user_in_sesion(System,System_User_In_Session):-
	caddddr(System,System_User_In_Session).

%Descripcion:Recupera los id de los chatbots del sistema
%Predicado:get_system_chatbots_id(System,System_Chatbots_Id) 
%Clausulas:
get_system_chatbots_id(System,System_Chatbots_Id):-
    get_flow_options(System,System_Chatbots),
    maplist(car,System_Chatbots,System_Chatbots_Id).

%Descripcion:Recupera los nombres de los usuarios del sistema
%Predicado:get_system_users_names(System,System_Users_Names) 
%Clausulas:
get_system_users_names(System,System_Users_Names):-
	get_system_users(System,System_Users),
	maplist(car,System_Users,System_Users_Names).

%Descripcion:Recupera el chatbot inicial
%Predicado:get_system_initial_chatbot(System,System_InitialChatbotCodeLink,Initial_Chatbot) 
%Clausulas:
get_system_initial_chatbot(System,_):-
	get_system_chatbots(System,System_Chatbots),
	System_Chatbots=[],
	write("No hay Chatbots disponibles"),
	nl.
get_system_initial_chatbot(System,Initial_Chatbot):-
	get_system_chatbots(System,System_Chatbots),
    get_system_initialchatbotcodelink(System,System_Initial_Chatbot_Code_Link),
	car(System_Chatbots,Chatbot),
	get_chatbot_id(Chatbot,Chatbot_Id),
	Chatbot_Id=System_Initial_Chatbot_Code_Link,
    get_chatbot_name(Chatbot,Chatbot_Name),
	get_chatbot_welcomemsg(Chatbot,Chatbot_WelcomeMsg),
	get_chatbot_startflowid(Chatbot,Chatbot_StartFlowId),
    get_chatbot_flows(Chatbot,Chatbot_Flows),
	chatbot(Chatbot_Id,Chatbot_Name,Chatbot_WelcomeMsg,Chatbot_StartFlowId,Chatbot_Flows,Initial_Chatbot).
get_system_initial_chatbot(System,Initial_Chatbot):-
	get_system_chatbots(System,System_Chatbots),
    get_system_initialchatbotcodelink(System,System_Initial_Chatbot_Code_Link),
	car(System_Chatbots,Chatbot),
	get_chatbot_id(Chatbot,Chatbot_Id),
	\+ Chatbot_Id=System_Initial_Chatbot_Code_Link,
	delete_first_element(System_Chatbots,System_New_Chatbots),
	get_system_name(System,System_Name),
	get_system_users(System,System_Users),
	get_system_user_in_sesion(System,System_User_In_Session),
	system(System_Name,System_Initial_Chatbot_Code_Link,System_New_Chatbots,System_Users,System_User_In_Session,New_System),
	get_system_initial_chatbot(New_System,Initial_Chatbot).

%Descripcion:Recupera un usuario por su nombre
%Predicado:get_user_byname(System_Users,User_Name1,User1) 
%Clausulas:

get_user_byname(System_Users,_,_):-
	System_Users=[],
	write("El usuario no existe"),
	nl.
get_user_byname(System_Users,User_Name,User):-
	car(System_Users,User1),
	get_user_name(User1,User_Name1),
	User_Name=User_Name1,
	get_user_email(User1,User_Email1),
	get_user_password(User1,User_Password1),
	get_user_chathistory(User1,User_ChatHistory1),
	user(User_Name1,User_Email1,User_Password1,User_ChatHistory1,User).
get_user_byname(System_Users,User_Name,User):-
	car(System_Users,User1),
	get_user_name(User1,User_Name1),
	\+ User_Name1=User_Name,
	delete_first_element(System_Users,New_System_Users),
	get_user_byname(New_System_Users,User_Name,User).

%Modificadores

%Descripcion:Añade un chatbot al sistema sin repetir el id
%Predicado:systemaddchatbot(System,Chatbot,New_System) 
%Clausulas:
systemaddchatbot(System,_,_):-
	\+ is_system(System),
	write("Sistema invalido"),
	nl.
systemaddchatbot(_,Chatbot,_):-
	\+ is_chatbot(Chatbot),
	write("Chatbot invalido"),
	nl.
systemaddchatbot(System,Chatbot,New_System):-
	is_system(System),
	is_chatbot(Chatbot),
	get_system_chatbots_id(System,System_Chatbots_Id),
	get_chatbot_id(Chatbot,Chatbot_Id),
	in(System_Chatbots_Id,Chatbot_Id),
	get_system_name(System,System_Name),
	get_system_initialchatbotcodelink(System,System_Initial_Chatbot_Code_Link),
	get_system_chatbots(System,System_Chatbots),
	get_system_users(System,System_Users),
	get_system_user_in_sesion(System,System_User_In_Session),
	system(System_Name,System_Initial_Chatbot_Code_Link,System_Chatbots,System_Users,System_User_In_Session,New_System).
systemaddchatbot(System,Chatbot,New_System):-
	is_system(System),
	is_chatbot(Chatbot),
	get_system_chatbots_id(System,System_Chatbots_Id),
	get_chatbot_id(Chatbot,Chatbot_Id),
	\+ in(System_Chatbots_Id,Chatbot_Id),
	get_system_name(System,System_Name),
	get_system_initialchatbotcodelink(System,System_Initial_Chatbot_Code_Link),
	get_system_chatbots(System,System_Chatbots),
	get_system_users(System,System_Users),
	get_system_user_in_sesion(System,System_User_In_Session),
	put_last(System_Chatbots,Chatbot,New_Chatbots),
	system(System_Name,System_Initial_Chatbot_Code_Link,New_Chatbots,System_Users,System_User_In_Session,New_System).

%Descripcion:Añade un usuario al sistema sin repetir el nombre
%Predicado:systemadduser(System,User,New_System) 
%Clausulas:
systemadduser(System,_,_):-
	\+ is_system(System),
	write("Sistema invalido"),
	nl.
systemadduser(_,User,_):-
	\+ is_user(User),
	write("Usuario invalido"),
	nl.
systemadduser(System,User,New_System):-
	is_system(System),
	is_user(User),
	get_system_users_names(System,System_Users_Names),
	get_user_name(User,User_Name),
	in(System_Users_Names,User_Name),
	get_system_name(System,System_Name),
	get_system_initialchatbotcodelink(System,System_Initial_Chatbot_Code_Link),
	get_system_chatbots(System,System_Chatbots),
	get_system_users(System,System_Users),
	get_system_user_in_sesion(System,System_User_In_Session),
	system(System_Name,System_Initial_Chatbot_Code_Link,System_Chatbots,System_Users,System_User_In_Session,New_System).
systemadduser(System,User,New_System):-
	is_system(System),
	is_user(User),
	get_system_users_names(System,System_Users_Names),
	get_user_name(User,User_Name),
	\+ in(System_Users_Names,User_Name),
	get_system_name(System,System_Name),
	get_system_initialchatbotcodelink(System,System_Initial_Chatbot_Code_Link),
	get_system_chatbots(System,System_Chatbots),
	get_system_users(System,System_Users),
	get_system_user_in_sesion(System,System_User_In_Session),
	put_last(System_Users,User,New_Users),
	system(System_Name,System_Initial_Chatbot_Code_Link,System_Chatbots,New_Users,System_User_In_Session,New_System).

%Descripcion:Inicia sesion con un usuario ya registrado
%Predicado:systemlogin(System,User,New_System) 
%Clausulas:
systemlogin(System,_,_):-
	\+ is_system(System),
	write("Sistema invalido"),
	nl.
systemlogin(_,User,_):-
	\+ is_user(User),
	write("Usuario invalido"),
	nl.
systemlogin(System,User,New_System):-
	is_system(System),
	is_user(User),
	get_system_users_names(System,System_Users_Names),
	get_user_name(User,User_Name),
	\+ in(System_Users_Names,User_Name),
	get_system_name(System,System_Name),
	get_system_initialchatbotcodelink(System,System_Initial_Chatbot_Code_Link),
	get_system_chatbots(System,System_Chatbots),
	get_system_users(System,System_Users),
	get_system_user_in_sesion(System,System_User_In_Session),
	system(System_Name,System_Initial_Chatbot_Code_Link,System_Chatbots,System_Users,System_User_In_Session,New_System).
systemlogin(System,User,New_System):-
	is_system(System),
	is_user(User),
	get_system_users_names(System,System_Users_Names),
	get_user_name(User,User_Name),
	in(System_Users_Names,User_Name),
	get_system_name(System,System_Name),
	get_system_initialchatbotcodelink(System,System_Initial_Chatbot_Code_Link),
	get_system_chatbots(System,System_Chatbots),
	get_system_users(System,System_Users),
	get_system_user_in_sesion(System,System_User_In_Session),
	System_User_In_Session=[],
	put_first(User,System_User_In_Session,New_User_In_Session),
	system(System_Name,System_Initial_Chatbot_Code_Link,System_Chatbots,System_Users,New_User_In_Session,New_System).

%Descripcion:Cierra sesion
%Predicado:systemlogout(System,New_System) 
%Clausulas:
systemlogout(System,_):-
	\+ is_system(System),
	write("Sistema invalido"),
	nl.
systemlogout(System,New_System):-
	is_system(System),
	get_system_name(System,System_Name),
	get_system_initialchatbotcodelink(System,System_Initial_Chatbot_Code_Link),
	get_system_chatbots(System,System_Chatbots),
	get_system_users(System,System_Users),
	system(System_Name,System_Initial_Chatbot_Code_Link,System_Chatbots,System_Users,[],New_System).

%Otros

%Descripcion:Interactua con el sistema configurado y recopila las respuestas
%Predicado:systemtalkrec(System,Msg,SystemOut) 
%Clausulas:
systemtalkrec(_,Msg,_):-
	\+ string(Msg),
	\+ integer(Msg),
	write("Mensaje invalido"),
	nl.
systemtalkrec(System,_,_):-
	get_system_user_in_sesion(System,System_User_In_Session),
	System_User_In_Session=[],
    write("No has iniciado sesion"),
    nl.
systemtalkrec(System,Msg,SystemOut):-
	string(Msg),
	get_system_user_in_sesion(System,System_User_In_Session),
	\+ System_User_In_Session=[],
    car(System_User_In_Session,System_User_In_Session1),
	get_user_name(System_User_In_Session1,User_Name),
	get_system_users(System,System_Users),
	get_user_byname(System_Users,User_Name,User),
	get_user_chathistory(User,ChatHistory),
	\+ ChatHistory=[],
	concat(User_Name,":",Out),
	addmsg([Out,Msg],ChatHistory,New_ChatHistory1),
	get_system_initial_chatbot(System,Initial_Chatbot),
	get_chatbot_name(Initial_Chatbot,Chatbot_Name),
	get_chatbot_welcomemsg(Initial_Chatbot,Chatbot_WelcomeMsg),
	concat(Chatbot_Name,":",Out1),
	addmsg([Out1,Chatbot_WelcomeMsg],New_ChatHistory1,New_ChatHistory2),
	get_chatbot_startflowid(Initial_Chatbot,Chatbot_StartFlowId),
	get_start_flow(Initial_Chatbot,Chatbot_StartFlowId,Start_Flow),
	get_flow_namemsg(Start_Flow,Flow_Name_Msg),
	addmsg(["->",Flow_Name_Msg],New_ChatHistory2,New_ChatHistory3),
	get_flow_options(Start_Flow,Flow_Options),
	addmsgv2(Flow_Options,New_ChatHistory3,NewChatHistory4),
	get_option_bykeyword(Start_Flow,Msg,Option),
	get_option_chatbotcodelink(Option,Option_ChatbotCodelink),
	get_system_name(System,System_Name),
	get_system_chatbots(System,System_Chatbots),
	get_user_email(User,User_Email),
	get_user_password(User,User_Password),
	user(User_Name,User_Email,User_Password,NewChatHistory4,New_User),
	put_first(New_User,System_Users,New_System_Users),
	system(System_Name,Option_ChatbotCodelink,System_Chatbots,New_System_Users,System_User_In_Session,SystemOut).
systemtalkrec(System,Msg,SystemOut):-
	integer(Msg),
	get_system_user_in_sesion(System,System_User_In_Session),
	\+ System_User_In_Session=[],
    car(System_User_In_Session,System_User_In_Session1),
	get_user_name(System_User_In_Session1,User_Name),
	get_system_users(System,System_Users),
	get_user_byname(System_Users,User_Name,User),
	get_user_chathistory(User,ChatHistory),
	\+ ChatHistory=[],
	concat(User_Name,":",Out),
	addmsg([Out,Msg],ChatHistory,New_ChatHistory1),
	get_system_initial_chatbot(System,Initial_Chatbot),
	get_chatbot_name(Initial_Chatbot,Chatbot_Name),
	get_chatbot_welcomemsg(Initial_Chatbot,Chatbot_WelcomeMsg),
	concat(Chatbot_Name,":",Out1),
	addmsg([Out1,Chatbot_WelcomeMsg],New_ChatHistory1,New_ChatHistory2),
	get_chatbot_startflowid(Initial_Chatbot,Chatbot_StartFlowId),
	get_start_flow(Initial_Chatbot,Chatbot_StartFlowId,Start_Flow),
	get_flow_namemsg(Start_Flow,Flow_Name_Msg),
	addmsg(["->",Flow_Name_Msg],New_ChatHistory2,New_ChatHistory3),
	get_flow_options(Start_Flow,Flow_Options),
	addmsgv2(Flow_Options,New_ChatHistory3,NewChatHistory4),
	get_option_byid(Start_Flow,Msg,Option),
	get_option_chatbotcodelink(Option,Option_ChatbotCodelink),
	get_system_name(System,System_Name),
	get_system_chatbots(System,System_Chatbots),
	get_user_email(User,User_Email),
	get_user_password(User,User_Password),
	user(User_Name,User_Email,User_Password,NewChatHistory4,New_User),
	put_first(New_User,System_Users,New_System_Users),
	system(System_Name,Option_ChatbotCodelink,System_Chatbots,New_System_Users,System_User_In_Session,SystemOut).
systemtalkrec(System,Msg,_):-
	get_system_user_in_sesion(System,System_User_In_Session),
	\+ System_User_In_Session=[],
    car(System_User_In_Session,System_User_In_Session1),
	get_user_name(System_User_In_Session1,User_Name),
	get_system_users(System,System_Users),
	get_user_byname(System_Users,User_Name,User),
	get_user_chathistory(User,User_ChatHistory),
	User_ChatHistory=[],
	write("Ingresa la fecha de la interaccion (Como string) con el siguiente formato (Dia/Mes/Año):"),
	nl,
	read(Date),
	chathistory(Date,ChatHistory),
	get_system_name(System,System_Name),
	get_system_chatbots(System,System_Chatbots),
    get_system_initialchatbotcodelink(System,System_Initial_Chatbot_Code_Link),
	get_user_email(User,User_Email),
	get_user_password(User,User_Password),
	user(User_Name,User_Email,User_Password,ChatHistory,New_User),
	put_first(New_User,System_Users,New_System_Users),
	system(System_Name,System_Initial_Chatbot_Code_Link,System_Chatbots,New_System_Users,System_User_In_Session,New_System),
	systemtalkrec(New_System,Msg,_).
	
%Descripcion:Desplega el registro de interaccion
%Predicado:systemSynthesis(System,User_Name)
%Clausulas:
systemsynthesis(System,User_Name):-
	get_system_users(System,System_Users),
	get_user_byname(System_Users,User_Name,User),
	get_user_chathistory(User,User_ChatHistory),
	displaychat(User_ChatHistory).