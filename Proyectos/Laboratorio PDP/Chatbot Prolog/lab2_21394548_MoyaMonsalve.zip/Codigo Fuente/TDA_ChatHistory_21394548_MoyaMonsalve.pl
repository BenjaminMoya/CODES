:-consult("TDA_Base_21394548_MoyaMonsalve.pl").

%TDA Chat History | Version 1.2

%-----------------------------------------------------------------------

%Dominio:
%Date:String
%Mensaje:String
%Msg1:String
%Msg2:String
%Option_Code:Integer
%Option_Msg:String
%Flow_Options:List
%ChatHistory:List
%NewChatHistory:List
%Display:List

%-----------------------------------------------------------------------

%Constructores

%Descripcion:Crea un historial de chat
%Predicado:chathistory(Date,[Date|_]):-
%Clausulas:
chathistory(Date,[Date|_]):-
	string(Date).

%Pertenencia

%Descripcion:Verifica si el elemento es un historial
%Predicado:is_chathistory(ChatHistory) 
%Clausulas:
is_chathistory(ChatHistory):-
	get_date(ChatHistory,Date),
    chathistory(Date,ChatHistory).

%Selectores

%Descripcion:Recupera el mensaje del historial
%Predicado:get_msg(ChatHistory,Mensajes) 
%Clausulas:
get_msg(ChatHistory,Mensaje):-
	car(ChatHistory,Mensaje).

%Descripcion:Recupera el string del mensaje
%Predicado:get_string_msg(ChatHistory,String) 
%Clausulas:
get_string_msg(ChatHistory,String):-
	car(ChatHistory,Mensaje),
	cadr(Mensaje,String).

%Modificadores

%Descripcion:Añade un mensaje al historial
%Predicado:addmsg(Mensaje,ChatHistory,New_ChatHistory)
%Clausulas:
addmsg(Mensaje,ChatHistory,New_ChatHistory):-
    put_last(ChatHistory,Mensaje,New_ChatHistory).

%Descripcion:Añade un mensaje al historial
%Predicado:addmsgv2(Flow_Options,Counter,ChatHistory,NewChatHistory)
%Clausulas:
addmsgv2(Flow_Options,_,_):-
    Flow_Options=[],
	write("Todos los mensajes añadidos a la simulacion"),
	nl.
addmsgv2(Flow_Options,ChatHistory,NewChatHistory):-
	car(Flow_Options,Option),
	get_option_msg(Option,Option_Msg),
	get_option_code(Option,Option_Code),
	concat(Option_Code,")",Out),
	put_last(ChatHistory,[Out,Option_Msg],NewChatHistory),
    delete_first_element(Flow_Options,New_Flow_Options),
	addmsgv2(New_Flow_Options,NewChatHistory,_).

%Otros

%Descripcion:Muestra la recopilacion de mensajes del historial
%Predicado:display_chathistory(ChatHistory)
%Clausulas:
displaychat(ChatHistory):-
    ChatHistory=[],
    write("Fin del registro"),
    nl.
displaychat(ChatHistory):-
    get_msg(ChatHistory,Mensaje),
    string(Mensaje),
    write(Mensaje),
    nl,
    delete_first_element(ChatHistory,New_ChatHistory),
    displaychat(New_ChatHistory).
displaychat(ChatHistory):-
    get_msg(ChatHistory,Mensaje),
    \+ string(Mensaje),
    car(Mensaje,Msg1),
    cadr(Mensaje,Msg2),
    write(Msg1),
    write(Msg2),
    nl,
    delete_first_element(ChatHistory,New_ChatHistory),
    displaychat(New_ChatHistory).