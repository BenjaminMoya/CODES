:-consult("TDA_Base_21394548_MoyaMonsalve.pl").

%TDA User | Version 1.0

%-----------------------------------------------------------------------

%Dominio:
%User_Name:String
%User_Email:String
%User_Password:String
%User_ChatHistory:List
%User:List
%NewName:String
%NewUser:List

%-----------------------------------------------------------------------

%Constructores

%Descripcion:Crea un usuario
%Predicado:user(User_Name,User_Email,User_Password,User_ChatHistory) 
%Clausulas:
user(User_Name,User_Email,User_Password,User_ChatHistory,[User_Name,User_Email,User_Password,User_ChatHistory]):-
	string(User_Name),
	string(User_Email),
	string(User_Password),
	\+ string(User_ChatHistory).

%Pertenencia

%Descripcion:Verifica si un elemento es un usuario
%Predicado:is_user(User) 
%Clausulas:
is_user(User):-
	get_user_name(User,User_Name),
	get_user_email(User,User_Email),
	get_user_password(User,User_Password),
    get_user_chathistory(User,User_ChatHistory),
	user(User_Name,User_Email,User_Password,User_ChatHistory,User).

%Selectores

%Descripcion:Recupera el nombre del usuario
%Predicado:get_user_name(User,User_Name) 
%Clausulas:
get_user_name(User,User_Name):-
	car(User,User_Name).

%Descripcion:Recupera el email del usuario
%Predicado:get_user_email(User,User_Email) 
%Clausulas:
get_user_email(User,User_Email):-
	cadr(User,User_Email).

%Descripcion:Recupera la contraseña del usuario
%Predicado:get_user_password(User,User_Password) 
%Clausulas:
get_user_password(User,User_Password):-
	caddr(User,User_Password).

%Descripcion:Recupera el historial de chat del usuario
%Predicado:get_user_chathistory(User,User_ChatHistory) 
%Clausulas:
get_user_chathistory(User,User_ChatHistory):-
	cadddr(User,User_ChatHistory).

%Modificadores

%Descripcion:Cambia el nombre del usuario
%Predicado:set_user_name(User,NewName,NewUser) 
%Clausulas:
set_user_name(User,NewName,NewUser):-
	string(NewName),
	get_user_password(User,User_Password),
	get_user_email(User,User_Email),
	get_user_chathistory(User,User_ChatHistory),
	user(NewName,User_Email,User_Password,User_ChatHistory,NewUser).
