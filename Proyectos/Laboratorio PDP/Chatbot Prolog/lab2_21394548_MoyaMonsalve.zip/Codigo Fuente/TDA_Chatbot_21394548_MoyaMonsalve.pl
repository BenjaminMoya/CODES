:-consult("TDA_Base_21394548_MoyaMonsalve.pl").
:-consult("TDA_Flow_21394548_MoyaMonsalve.pl").

%TDA Chatbot | Version 1.3

%-----------------------------------------------------------------------

%Dominmio:
%Chatbot_Id:Integer
%Chatbot_Name:String
%Chatbot_WelcomeMsg:String
%Chatbot_StartFlowId:Integer
%Flow_Id:Integer
%Flow:List
%Start_Flow:List
%Chatbot_Flows:List
%Chatbot_Flows_Id:List
%Chatbot:List
%New_Chatbot:List
%New_Chatbot_Flows:List
%Flow_Name_Msg:String
%Flow_Options:List

%-----------------------------------------------------------------------

%Descripcion:Crea un chatbot
%Predicado:chatbot(Chatbot_Id,Chatbot_Name,Chatbot_WelcomeMsg,Chatbot_StartFlowId,Chatbot_Flows,Chatbot)
%Clausulas:
chatbot(Chatbot_Id,Chatbot_Name,Chatbot_WelcomeMsg,Chatbot_StartFlowId,Chatbot_Flows,[Chatbot_Id,Chatbot_Name,Chatbot_WelcomeMsg,Chatbot_StartFlowId,Chatbot_Flows]):-
	integer(Chatbot_Id),
	string(Chatbot_Name),
	string(Chatbot_WelcomeMsg),
	integer(Chatbot_StartFlowId),
	\+ integer(Chatbot_Flows),
	\+ string(Chatbot_Flows).

%Pertenencia

%Descripcion:Verifica si un elemento es un chatbot
%Predicado:is_chatbot(Chatbot) 
%Clausulas:
is_chatbot(Chatbot):-
    get_chatbot_id(Chatbot,Chatbot_Id),
    get_chatbot_name(Chatbot,Chatbot_Name),
    get_chatbot_welcomemsg(Chatbot,Chatbot_WelcomeMsg),
    get_chatbot_startflowid(Chatbot,Chatbot_StartFlowId),
    get_chatbot_flows(Chatbot,Chatbot_Flows),
    chatbot(Chatbot_Id,Chatbot_Name,Chatbot_WelcomeMsg,Chatbot_StartFlowId,Chatbot_Flows,Chatbot).

%Selectores

%Descripcion:Recupera el id del chatbot
%Predicado:get_chatbot_id(Chatbot,Chatbot_Id) 
%Clausulas:
get_chatbot_id(Chatbot,Chatbot_Id):-
	car(Chatbot,Chatbot_Id).

%Descripcion:Recupera el nombre del chatbot
%Predicado:get_chatbot_name(Chatbot,Chatbot_Id) 
%Clausulas:
get_chatbot_name(Chatbot,Chatbot_Name):-
	cadr(Chatbot,Chatbot_Name).

%Descripcion:Recupera el mensaje de bienvenida del chatbot
%Predicado:get_chatbot_welcomemsg(Chatbot,Chatbot_WelcomeMsg) 
%Clausulas:
get_chatbot_welcomemsg(Chatbot,Chatbot_WelcomeMsg):-
	caddr(Chatbot,Chatbot_WelcomeMsg).

%Descripcion:Recuper el id del flujo inicial
%Predicado:get_chatbot_startflowid(Chatbot,Chatbot_StartFlowId) 
%Clausulas:
get_chatbot_startflowid(Chatbot,Chatbot_StartFlowId):-
	cadddr(Chatbot,Chatbot_StartFlowId).

%Descripcion:Recupera los flujos del chatbot
%Predicado:get_chatbot_flows(Chatbot,Chatbot_Flows) 
%Clausulas:
get_chatbot_flows(Chatbot,Chatbot_Flows):-
	caddddr(Chatbot,Chatbot_Flows).

%Descripcion:Recupera los id de los flujos del chatbot
%Predicado:get_flows_id(Chatbot,Chatbot_Flows_Id)
%Clausulas:
get_flows_id(Chatbot,Chatbot_Flows_Id):-
	get_chatbot_flows(Chatbot,Chatbot_Flows),
	maplist(car,Chatbot_Flows,Chatbot_Flows_Id).

%Descripcion:Recupera el flujo inicial del chatbot
%Predicado:get_start_flow(Chatbot,Chatbot_StartFlowId,Start_Flow) 
%Clausulas:
get_start_flow(Chatbot,_,_):-
	get_chatbot_flows(Chatbot,Chatbot_Flows),
	Chatbot_Flows=[],
	write("No hay flujos disponibles"),
	nl.
get_start_flow(Chatbot,Chatbot_StartFlowId,Start_Flow):-
	get_chatbot_flows(Chatbot,Chatbot_Flows),
	car(Chatbot_Flows,Flow),
	get_flow_id(Flow,Flow_Id),
	Chatbot_StartFlowId=Flow_Id,
    get_flow_namemsg(Flow,Flow_Name_Msg),
    get_flow_options(Flow,Flow_Options),
	flow(Flow_Id,Flow_Name_Msg,Flow_Options,Start_Flow).
get_start_flow(Chatbot,Chatbot_StartFlowId,Star_Flow):-
	get_chatbot_flows(Chatbot,Chatbot_Flows),
	car(Chatbot_Flows,Flow),
	get_flow_id(Flow,Flow_Id),
	\+ Chatbot_StartFlowId=Flow_Id,
	delete_first_element(Chatbot_Flows,Chatbot_New_Flows),
	get_chatbot_id(Chatbot,Chatbot_Id),
	get_chatbot_name(Chatbot,Chatbot_Name),
	get_chatbot_welcomemsg(Chatbot,Chatbot_WelcomeMsg),
	get_chatbot_startflowid(Chatbot,Chatbot_StartFlowId),
	chatbot(Chatbot_Id,Chatbot_Name,Chatbot_WelcomeMsg,Chatbot_StartFlowId,Chatbot_New_Flows,New_Chatbot),
	get_start_flow(New_Chatbot,Chatbot_StartFlowId,Star_Flow).
	
%Modificadores

%Descripcion:Añade un flujo al chatbot
%Predicado:chatbotaddflow(Chatbot,Flow,New_Chatbot) 
%Clausulas:
chatbotaddflow(Chatbot,_,_):- 
	\+ is_chatbot(Chatbot),
	write("Chatbot invalido"),
	nl.
chatbotaddflow(_,Flow,_):- 
	\+ is_flow(Flow),
	write("Flujo invalido"),
	nl.
chatbotaddflow(Chatbot,Flow,New_Chatbot):-
    is_chatbot(Chatbot),
    is_flow(Flow),
	get_chatbot_flows(Chatbot,Chatbot_Flows),
	get_flows_id(Chatbot,Chatbot_Flows_Id),
	get_flow_id(Flow,Flow_Id),
	in(Chatbot_Flows_Id,Flow_Id),
	get_chatbot_id(Chatbot,Chatbot_Id),
	get_chatbot_name(Chatbot,Chatbot_Name),
	get_chatbot_welcomemsg(Chatbot,Chatbot_WelcomeMsg),
	get_chatbot_startflowid(Chatbot,Chatbot_StartFlowId),
	chatbot(Chatbot_Id,Chatbot_Name,Chatbot_WelcomeMsg,Chatbot_StartFlowId,Chatbot_Flows,New_Chatbot).
chatbotaddflow(Chatbot,Flow,New_Chatbot):-
    is_chatbot(Chatbot),
    is_flow(Flow),
	get_chatbot_flows(Chatbot,Chatbot_Flows),
	get_flows_id(Chatbot,Chatbot_Flows_Id),
	get_flow_id(Flow,Flow_Id),
	\+ in(Chatbot_Flows_Id,Flow_Id),
	get_chatbot_id(Chatbot,Chatbot_Id),
	get_chatbot_name(Chatbot,Chatbot_Name),
	get_chatbot_welcomemsg(Chatbot,Chatbot_WelcomeMsg),
	get_chatbot_startflowid(Chatbot,Chatbot_StartFlowId),
	put_last(Chatbot_Flows,Flow,New_Chatbot_Flows),
	chatbot(Chatbot_Id,Chatbot_Name,Chatbot_WelcomeMsg,Chatbot_StartFlowId,New_Chatbot_Flows,New_Chatbot).